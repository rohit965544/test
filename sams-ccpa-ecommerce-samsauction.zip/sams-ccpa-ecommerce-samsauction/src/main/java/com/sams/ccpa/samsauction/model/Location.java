package com.sams.ccpa.samsauction.model;



import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Location {

	String regulation;
	 String document;
	String consented;
	String timestamp_unixtime_ms;
	String location;
	 String hardware_id;
}
