package com.sams.ccpa.samsauction.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class SourceInfo {
	String channel;
	String partner;
	String replay_request_id;
	String replay_job_id;
}
