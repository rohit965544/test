package com.sams.ccpa.samsauction.controller.service;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;

import com.sams.ccpa.samsauction.model.clearhousejson.SNowTicket;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component
public class CcpaService {
	

	
	public void processRequests(List<SNowTicket> tickets) {
		
		List<SNowTicket> accessTickets = new ArrayList<>();
		List<SNowTicket> deleteTickets = new ArrayList<>();
		
		 Set<Object[]> accessdataSet= new LinkedHashSet<Object[]>();
	       accessdataSet.add(new Object[] {"SYS_ID", "Membership_ID", "Email" ,"Request Data","Acknowledge date"});
	        
	     Set<Object[]> deletedataSet= new LinkedHashSet<Object[]>();
	      deletedataSet.add(new Object[] {"SYS_ID", "Membership_ID", "Email" ,"Request Data","Acknowledge date","response date"});
		
		 for(SNowTicket ticket:tickets) {
	        	
	        	
	        	if(ticket.getVariables() != null && ticket.getVariables().getRequestType() != null) {
	        		Object[] data = new Object[6];
	            	data[0] = ticket.getSysId();
	        		
	        		data[2] = ticket.getVariables().getEmail();
	        		
	        		if(ticket.getVariables().getPiBlob() != null) {
	        			data[1] = ticket.getVariables().getPiBlob().getCustomerID();
	        		}
	        		
	        		if(ticket.getVariables().getRequestType().equalsIgnoreCase("Access")) {
	        			accessdataSet.add(data);
	        			accessTickets.add(ticket);
	        			
	        		}
	        		else if(ticket.getVariables().getRequestType().equalsIgnoreCase("Delete")) {
	        			deletedataSet.add(data);
	        			deleteTickets.add(ticket);
	        			
	        		}
	        	}
	        }
		 
		 createExcel(accessdataSet,"access");
		 createExcel(deletedataSet,"delete");
		 
		
	}
	
	
	public void createExcel(Set<Object[]> dataSet,String type) {
		
		XSSFWorkbook workbook = new XSSFWorkbook(); 
		XSSFSheet sheet = workbook.createSheet("data");
		
       
        
        //Iterate over data and write to sheet 
        int rownum = 0;
        for (Object[] data : dataSet)
        {
            Row row = sheet.createRow(rownum++);
            int cellnum = 0;
            for (Object obj : data)
            {
              
               Cell cell = row.createCell(cellnum);
               if(obj instanceof String)
                    cell.setCellValue((String)obj);
                else if(obj instanceof Integer)
                    cell.setCellValue((Integer)obj);
               sheet.autoSizeColumn(cellnum++);
               
            }

        }
       
        try
        {
            FileOutputStream out = new FileOutputStream(new File(type + "_" + System.currentTimeMillis() + ".xlsx"));
            workbook.write(out);
            out.close();
            workbook.close();
            
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
		
		
	}

}
