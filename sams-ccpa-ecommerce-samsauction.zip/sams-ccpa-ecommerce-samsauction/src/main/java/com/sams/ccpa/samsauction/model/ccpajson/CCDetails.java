package com.sams.ccpa.samsauction.model.ccpajson;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CCDetails {
	String credit_card_type;
	String credit_card_number;
	String card_expiry_date;
	String credit_card_CVV;
	String credit_card_issuer;
}
