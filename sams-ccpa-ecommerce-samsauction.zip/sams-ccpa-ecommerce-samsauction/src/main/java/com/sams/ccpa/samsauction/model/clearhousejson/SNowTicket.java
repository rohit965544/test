package com.sams.ccpa.samsauction.model.clearhousejson;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SNowTicket {
	@JsonProperty("sys_id")
	private String sysId;

	private String state;

	private String number;

	@JsonProperty("request_item")
	private String requestItem;

	@JsonProperty("u_process_id")
	private String uProcessId;

	@JsonProperty("variables")
	private Variables variables;

	@JsonProperty("asset")
	private Asset asset;

}
