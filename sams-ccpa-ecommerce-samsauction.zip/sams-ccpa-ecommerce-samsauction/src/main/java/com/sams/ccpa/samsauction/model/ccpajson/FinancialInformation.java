package com.sams.ccpa.samsauction.model.ccpajson;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class FinancialInformation {
	List<BankDetails> bank_details;
	List<CCDetails> cc_details;
	List<DebitCardDetails> debit_card_details;
    List<TransactionHistory> transaction_history;
    List<CreditHistory> credit_history;
}
