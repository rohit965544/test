package com.sams.ccpa.samsauction.model.clearhousejson;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Variables {
	@JsonProperty("pi_blob")
	private PIBlob piBlob;

	@JsonProperty("ot_number")
	private String otNumber;

	@JsonProperty("enriched_customer_identities")
	private List<EnrichedCustomerId> enrichedCustomerIds;

	@JsonProperty("pi_first_name")
	private String piFirstName;

	@JsonProperty("pi_last_name")
	private String piLastName;

	@JsonProperty("request_type")
	private String requestType;

	@JsonProperty("pi_email")
	private String email;
}
