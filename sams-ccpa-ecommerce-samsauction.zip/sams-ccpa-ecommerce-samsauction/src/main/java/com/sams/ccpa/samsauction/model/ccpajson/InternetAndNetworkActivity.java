package com.sams.ccpa.samsauction.model.ccpajson;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class InternetAndNetworkActivity {
	List<TextMessage> text_messages;
	List<Cookies> cookies;
	List<BrowseAndSearchHistory> browse_and_search_history;
    List<ClickStream> click_stream;
    List<CallLogs> call_logs;  
}
