package com.sams.ccpa.samsauction.model.ccpajson;

public class OtherPersonalInformation {
	
	
	 String data_description;
     String data_category;
     String data_details;
	public String getData_description() {
		return data_description;
	}
	public void setData_description(String data_description) {
		this.data_description = data_description;
	}
	public String getData_category() {
		return data_category;
	}
	public void setData_category(String data_category) {
		this.data_category = data_category;
	}
	public String getData_details() {
		return data_details;
	}
	public void setData_details(String data_details) {
		this.data_details = data_details;
	}
     
     

}
