package com.sams.ccpa.samsauction.model.ccpajson;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class DebitCardDetails {
	String debit_card_type;
	String debit_card_number;
	String debit_card_expiry_date;
	String debit_card_CVV;
	String debit_card_issuing_bank;
}
