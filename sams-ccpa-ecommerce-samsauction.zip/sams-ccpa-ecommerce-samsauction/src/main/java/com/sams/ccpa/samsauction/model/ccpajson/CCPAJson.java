package com.sams.ccpa.samsauction.model.ccpajson;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@JsonInclude(Include.NON_NULL)
public class CCPAJson {
	
			//  "ot_request_id": "OtRequest", --> Mandatory Attribute
	    @JsonProperty("ot_request_id")
	    String  ot_request_id ;
	    //"asset_id": "String",  --> Mandatory Attribute
	    String asset_id;
	    //  "intakeRequestId":"String",  --> Mandatory Attribute
	    String intakeRequestId;
	    
	  // "extract_start_date": "String",
	    String extract_start_date;
	   // "extract_end_date": "String", 
	    String extract_end_date;
	   // "brand_code": "String",  --> Mandatory Attribute
	    String brand_code;
	    //"state_code": "String",
	    String state_code;
	    //"country_code": "String",
	    String country_code;
	    //"snow_request_id":"String",  --> Mandatory Attribute
	    String snow_request_id;
	    //"snow_task_id": "String",  --> Mandatory Attribute
	    String snow_task_id;
	    
	  PersonalIdentifiers personal_identifiers;
	    
	  List<DeviceAndOnlineIdentifiers> device_and_online_identifiers_and_related_information;
	  GovernmentIdentifiers government_identifiers;
	  List<TransactionPurchaseHistory> transaction_purchase_history;
	  EmploymentInformation employment_information;
	 List<EducationInformation> education_information;
	 IndividualPreferenceAndCharacteristics individual_preferences_and_characteristics;
	 ProtectedClassification characteristics_of_protected_classifications_under_california_or_federal_law;
	 DemographicInformation demographic_information;
	 BackgroundAndCriminalInformation background_and_criminal_information;
	 BiometricInformation biometric_information;
	 List<LocationInformation> location_information;
	 AudioVisualSensoryInformation audio_visual_and_other_sensory_information;
	 FinancialInformation financial_information;
	 HealthInsuranceInformation health_and_health_insurance_information;
	 InternetAndNetworkActivity internet_application_and_network_activity;
	 AutomobileInformation automobile_information;
	 List<InsuranceClaimsSummary> insurance_claims_summary;
	
	 CatchAll catch_all;
	 
	 
	
	public String getOt_request_id() {
		return ot_request_id;
	}
	public void setOt_request_id(String ot_request_id) {
		this.ot_request_id = ot_request_id;
	}
	public String getAsset_id() {
		return asset_id;
	}
	public void setAsset_id(String asset_id) {
		this.asset_id = asset_id;
	}
	public String getIntakeRequestId() {
		return intakeRequestId;
	}
	public void setIntakeRequestId(String intakeRequestId) {
		this.intakeRequestId = intakeRequestId;
	}
	public String getExtract_start_date() {
		return extract_start_date;
	}
	public void setExtract_start_date(String extract_start_date) {
		this.extract_start_date = extract_start_date;
	}
	public String getExtract_end_date() {
		return extract_end_date;
	}
	public void setExtract_end_date(String extract_end_date) {
		this.extract_end_date = extract_end_date;
	}
	public String getBrand_code() {
		return brand_code;
	}
	public void setBrand_code(String brand_code) {
		this.brand_code = brand_code;
	}
	public String getState_code() {
		return state_code;
	}
	public void setState_code(String state_code) {
		this.state_code = state_code;
	}
	public String getCountry_code() {
		return country_code;
	}
	public void setCountry_code(String country_code) {
		this.country_code = country_code;
	}
	public String getSnow_request_id() {
		return snow_request_id;
	}
	public void setSnow_request_id(String snow_request_id) {
		this.snow_request_id = snow_request_id;
	}
	public String getSnow_task_id() {
		return snow_task_id;
	}
	public void setSnow_task_id(String snow_task_id) {
		this.snow_task_id = snow_task_id;
	}
	public PersonalIdentifiers getPersonal_identifiers() {
		return personal_identifiers;
	}
	public void setPersonal_identifiers(PersonalIdentifiers personal_identifiers) {
		this.personal_identifiers = personal_identifiers;
	}
	public List<DeviceAndOnlineIdentifiers> getDevice_and_online_identifiers_and_related_information() {
		return device_and_online_identifiers_and_related_information;
	}
	public void setDevice_and_online_identifiers_and_related_information(
			List<DeviceAndOnlineIdentifiers> device_and_online_identifiers_and_related_information) {
		this.device_and_online_identifiers_and_related_information = device_and_online_identifiers_and_related_information;
	}
	public GovernmentIdentifiers getGovernment_identifiers() {
		return government_identifiers;
	}
	public void setGovernment_identifiers(
			GovernmentIdentifiers government_identifiers) {
		this.government_identifiers = government_identifiers;
	}
	public List<TransactionPurchaseHistory> getTransaction_purchase_history() {
		return transaction_purchase_history;
	}
	public void setTransaction_purchase_history(
			List<TransactionPurchaseHistory> transaction_purchase_history) {
		this.transaction_purchase_history = transaction_purchase_history;
	}
	public EmploymentInformation getEmployment_information() {
		return employment_information;
	}
	public void setEmployment_information(
			EmploymentInformation employment_information) {
		this.employment_information = employment_information;
	}
	public List<EducationInformation> getEducation_information() {
		return education_information;
	}
	public void setEducation_information(
			List<EducationInformation> education_information) {
		this.education_information = education_information;
	}
	public IndividualPreferenceAndCharacteristics getIndividual_preferences_and_characteristics() {
		return individual_preferences_and_characteristics;
	}
	public void setIndividual_preferences_and_characteristics(
			IndividualPreferenceAndCharacteristics individual_preferences_and_characteristics) {
		this.individual_preferences_and_characteristics = individual_preferences_and_characteristics;
	}
	public ProtectedClassification getCharacteristics_of_protected_classifications_under_california_or_federal_law() {
		return characteristics_of_protected_classifications_under_california_or_federal_law;
	}
	public void setCharacteristics_of_protected_classifications_under_california_or_federal_law(
			ProtectedClassification characteristics_of_protected_classifications_under_california_or_federal_law) {
		this.characteristics_of_protected_classifications_under_california_or_federal_law = characteristics_of_protected_classifications_under_california_or_federal_law;
	}
	public DemographicInformation getDemographic_information() {
		return demographic_information;
	}
	public void setDemographic_information(
			DemographicInformation demographic_information) {
		this.demographic_information = demographic_information;
	}
	public BackgroundAndCriminalInformation getBackground_and_criminal_information() {
		return background_and_criminal_information;
	}
	public void setBackground_and_criminal_information(
			BackgroundAndCriminalInformation background_and_criminal_information) {
		this.background_and_criminal_information = background_and_criminal_information;
	}
	public BiometricInformation getBiometric_information() {
		return biometric_information;
	}
	public void setBiometric_information(BiometricInformation biometric_information) {
		this.biometric_information = biometric_information;
	}
	public List<LocationInformation> getLocation_information() {
		return location_information;
	}
	public void setLocation_information(
			List<LocationInformation> location_information) {
		this.location_information = location_information;
	}
	public AudioVisualSensoryInformation getAudio_visual_and_other_sensory_information() {
		return audio_visual_and_other_sensory_information;
	}
	public void setAudio_visual_and_other_sensory_information(
			AudioVisualSensoryInformation audio_visual_and_other_sensory_information) {
		this.audio_visual_and_other_sensory_information = audio_visual_and_other_sensory_information;
	}
	public FinancialInformation getFinancial_information() {
		return financial_information;
	}
	public void setFinancial_information(FinancialInformation financial_information) {
		this.financial_information = financial_information;
	}
	public HealthInsuranceInformation getHealth_and_health_insurance_information() {
		return health_and_health_insurance_information;
	}
	public void setHealth_and_health_insurance_information(
			HealthInsuranceInformation health_and_health_insurance_information) {
		this.health_and_health_insurance_information = health_and_health_insurance_information;
	}
	public InternetAndNetworkActivity getInternet_application_and_network_activity() {
		return internet_application_and_network_activity;
	}
	public void setInternet_application_and_network_activity(
			InternetAndNetworkActivity internet_application_and_network_activity) {
		this.internet_application_and_network_activity = internet_application_and_network_activity;
	}
	public AutomobileInformation getAutomobile_information() {
		return automobile_information;
	}
	public void setAutomobile_information(
			AutomobileInformation automobile_information) {
		this.automobile_information = automobile_information;
	}
	public List<InsuranceClaimsSummary> getInsurance_claims_summary() {
		return insurance_claims_summary;
	}
	public void setInsurance_claims_summary(
			List<InsuranceClaimsSummary> insurance_claims_summary) {
		this.insurance_claims_summary = insurance_claims_summary;
	}
	public CatchAll getCatch_all() {
		return catch_all;
	}
	public void setCatch_all(CatchAll catch_all) {
		this.catch_all = catch_all;
	}
	 
	 
	 
	

}
