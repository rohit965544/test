package com.sams.ccpa.samsauction.model.clearhousejson;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AuthResponse {
	String token_type;
    String expires_in;
    String ext_expires_in;
    String expires_on;
   String not_before;
    String resource;
    String access_token; 
	
	
}
