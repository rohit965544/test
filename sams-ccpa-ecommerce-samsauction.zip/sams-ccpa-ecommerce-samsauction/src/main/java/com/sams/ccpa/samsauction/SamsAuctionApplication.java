package com.sams.ccpa.samsauction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SamsAuctionApplication {

	public static void main(String[] args) {
		
        
		SpringApplication.run(SamsAuctionApplication.class, args);
	}

}
