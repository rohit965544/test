package com.sams.ccpa.samsauction.model.ccpajson;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BackgroundAndCriminalInformation {
	List<BackgroundCheck> background_check;
	
}
