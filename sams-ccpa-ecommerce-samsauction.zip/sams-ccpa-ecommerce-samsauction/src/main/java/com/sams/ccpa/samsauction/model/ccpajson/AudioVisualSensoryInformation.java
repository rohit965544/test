package com.sams.ccpa.samsauction.model.ccpajson;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AudioVisualSensoryInformation {
	String[] in_store_cameras_xref;
	String[] recordings_of_phone_calls_xref;
}
