package com.sams.ccpa.samsauction.model.clearhousejson;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Asset {

	@JsonProperty("u_asset_name")
	private String assetName;

	@JsonProperty("number")
	private String assetNumber;

}
