package com.sams.ccpa.samsauction.model.ccpajson;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@JsonInclude(Include.NON_NULL)
public class Address {

	String type;
	String address_line_1;
	String address_line_2;
	String city;
	String county_or_province;
	String state;
	String zipcode;
       
}
