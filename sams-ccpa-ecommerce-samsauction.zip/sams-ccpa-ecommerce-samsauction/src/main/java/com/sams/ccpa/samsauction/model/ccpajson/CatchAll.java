package com.sams.ccpa.samsauction.model.ccpajson;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CatchAll {
	List<OtherData> other_data ;
	
}
