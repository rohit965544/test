package com.sams.ccpa.samsauction.model.ccpajson;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class VehicleInformation {

	String make_of_vehicle;
	String model_of_vehicle;
	String year_of_vehicle;
	String vehicle_VIN;
	String license_number;
	String license_state;
	String insurance_policy_number;
}
