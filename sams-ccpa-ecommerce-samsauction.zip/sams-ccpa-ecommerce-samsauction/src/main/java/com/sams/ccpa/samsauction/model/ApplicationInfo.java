package com.sams.ccpa.samsauction.model;

import com.fasterxml.jackson.annotation.JsonPropertyDescription;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ApplicationInfo {
	String application_name;
	String application_version;
	String application_build_number;
	String install_referrer;
	@JsonPropertyDescription("package")
	String package_info;
	String os;
}
