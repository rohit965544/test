package com.sams.ccpa.samsauction.model.ccpajson;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class GovernmentIdentifiers {
	
	List<NationalIdentification> national_identification_number;
	List<DriversLicense> drivers_licenses;
	List<ProfessionalLicense> professional_licenses;
     List<Passport> passports;
     List<FederalProgramDetail> federal_program_details; 
     List<LienDetails> lien_details;    
     String[] alien_registration;

}
