package com.sams.ccpa.samsauction.model.ccpajson;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class LienDetails {
	String lien_against_claimant;
	String lien_type_description;
	String lien_status;
	String lien_number;
	String lien_amount;
}
