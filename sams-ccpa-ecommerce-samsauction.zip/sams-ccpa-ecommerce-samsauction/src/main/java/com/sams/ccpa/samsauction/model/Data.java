package com.sams.ccpa.samsauction.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Data {
	String push_message_token;
	String custom_event_type;
	String event_name;
	 String timestamp_unixtime_ms;
	 String event_id;
	String source_message_id;
	 String session_start_unixtime_ms;
	 String event_start_unixtime_ms;
	 String is_goal_defined;
	 String lifetime_value_change;
	 String lifetime_value_attribute_name;
	 String data_connection_type;
	 String event_num;
	 String view_controller;
	 String is_main_thread;
	 String canonical_name;
	 String push_message_type;
	 ShoppingCart shopping_cart;
	 
	 
	public String getCustom_event_type() {
		return custom_event_type;
	}
	public void setCustom_event_type(String custom_event_type) {
		this.custom_event_type = custom_event_type;
	}
	public String getEvent_name() {
		return event_name;
	}
	public void setEvent_name(String event_name) {
		this.event_name = event_name;
	}
	public String getTimestamp_unixtime_ms() {
		return timestamp_unixtime_ms;
	}
	public void setTimestamp_unixtime_ms(String timestamp_unixtime_ms) {
		this.timestamp_unixtime_ms = timestamp_unixtime_ms;
	}
	public String getEvent_id() {
		return event_id;
	}
	public void setEvent_id(String event_id) {
		this.event_id = event_id;
	}
	public String getSource_message_id() {
		return source_message_id;
	}
	public void setSource_message_id(String source_message_id) {
		this.source_message_id = source_message_id;
	}
	public String getSession_start_unixtime_ms() {
		return session_start_unixtime_ms;
	}
	public void setSession_start_unixtime_ms(String session_start_unixtime_ms) {
		this.session_start_unixtime_ms = session_start_unixtime_ms;
	}
	public String getEvent_start_unixtime_ms() {
		return event_start_unixtime_ms;
	}
	public void setEvent_start_unixtime_ms(String event_start_unixtime_ms) {
		this.event_start_unixtime_ms = event_start_unixtime_ms;
	}
	
	public String getIs_goal_defined() {
		return is_goal_defined;
	}
	public void setIs_goal_defined(String is_goal_defined) {
		this.is_goal_defined = is_goal_defined;
	}
	public String getLifetime_value_change() {
		return lifetime_value_change;
	}
	public void setLifetime_value_change(String lifetime_value_change) {
		this.lifetime_value_change = lifetime_value_change;
	}
	public String getLifetime_value_attribute_name() {
		return lifetime_value_attribute_name;
	}
	public void setLifetime_value_attribute_name(
			String lifetime_value_attribute_name) {
		this.lifetime_value_attribute_name = lifetime_value_attribute_name;
	}
	public String getData_connection_type() {
		return data_connection_type;
	}
	public void setData_connection_type(String data_connection_type) {
		this.data_connection_type = data_connection_type;
	}
	public String getEvent_num() {
		return event_num;
	}
	public void setEvent_num(String event_num) {
		this.event_num = event_num;
	}
	public String getView_controller() {
		return view_controller;
	}
	public void setView_controller(String view_controller) {
		this.view_controller = view_controller;
	}
	public String getIs_main_thread() {
		return is_main_thread;
	}
	public void setIs_main_thread(String is_main_thread) {
		this.is_main_thread = is_main_thread;
	}
	public String getCanonical_name() {
		return canonical_name;
	}
	public void setCanonical_name(String canonical_name) {
		this.canonical_name = canonical_name;
	}
	 
	 
}
