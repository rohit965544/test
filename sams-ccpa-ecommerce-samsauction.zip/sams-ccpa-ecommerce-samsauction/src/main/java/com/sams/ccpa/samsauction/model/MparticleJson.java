package com.sams.ccpa.samsauction.model;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MparticleJson {
	
	String source_request_id;
	List<Events> events;
	DeviceInfo device_info;
	ApplicationInfo application_info;
	List<String> deleted_user_attributes;
	UserIdentities user_identities; //check for otherfields in the class
	String environment;
	String api_key;//check fro the type 
	
	String ip;
	String lock_key;//check type
	SourceInfo source_info;
	String mp_deviceid;
	String attribution_info;//check type
	String timestamp_unixtime_ms;
	String batch_id;//confirm the type
	String mpid;//confirm the type
	String sdk_version;//check the type
	
	ConsentState consent_state;//need to check whether map will do

	public String getSource_request_id() {
		return source_request_id;
	}

	public void setSource_request_id(String source_request_id) {
		this.source_request_id = source_request_id;
	}

	public List<Events> getEvents() {
		return events;
	}

	public void setEvents(List<Events> events) {
		this.events = events;
	}

	public DeviceInfo getDevice_info() {
		return device_info;
	}

	public void setDevice_info(DeviceInfo device_info) {
		this.device_info = device_info;
	}

	public ApplicationInfo getApplication_info() {
		return application_info;
	}

	public void setApplication_info(ApplicationInfo application_info) {
		this.application_info = application_info;
	}


	public List<String> getDeleted_user_attributes() {
		return deleted_user_attributes;
	}

	public void setDeleted_user_attributes(List<String> deleted_user_attributes) {
		this.deleted_user_attributes = deleted_user_attributes;
	}

	public UserIdentities getUser_identities() {
		return user_identities;
	}

	public void setUser_identities(UserIdentities user_identities) {
		this.user_identities = user_identities;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public String getApi_key() {
		return api_key;
	}

	public void setApi_key(String api_key) {
		this.api_key = api_key;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	

	public String getLock_key() {
		return lock_key;
	}

	public void setLock_key(String lock_key) {
		this.lock_key = lock_key;
	}

	public SourceInfo getSource_info() {
		return source_info;
	}

	public void setSource_info(SourceInfo source_info) {
		this.source_info = source_info;
	}

	public String getMp_deviceid() {
		return mp_deviceid;
	}

	public void setMp_deviceid(String mp_deviceid) {
		this.mp_deviceid = mp_deviceid;
	}

	public String getAttribution_info() {
		return attribution_info;
	}

	public void setAttribution_info(String attribution_info) {
		this.attribution_info = attribution_info;
	}

	public String getTimestamp_unixtime_ms() {
		return timestamp_unixtime_ms;
	}

	public void setTimestamp_unixtime_ms(String timestamp_unixtime_ms) {
		this.timestamp_unixtime_ms = timestamp_unixtime_ms;
	}

	public String getBatch_id() {
		return batch_id;
	}

	public void setBatch_id(String batch_id) {
		this.batch_id = batch_id;
	}

	public String getMpid() {
		return mpid;
	}

	public void setMpid(String mpid) {
		this.mpid = mpid;
	}

	public String getSdk_version() {
		return sdk_version;
	}

	public void setSdk_version(String sdk_version) {
		this.sdk_version = sdk_version;
	}

	public ConsentState getConsent_state() {
		return consent_state;
	}

	public void setConsent_state(ConsentState consent_state) {
		this.consent_state = consent_state;
	}
	
	

}
