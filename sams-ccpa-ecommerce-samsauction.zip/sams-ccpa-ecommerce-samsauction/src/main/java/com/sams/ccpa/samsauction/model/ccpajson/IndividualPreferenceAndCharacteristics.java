package com.sams.ccpa.samsauction.model.ccpajson;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class IndividualPreferenceAndCharacteristics {
	String[] household_age_indicator;
	String[] designated_market_area_code;
	String[] estimated_income_identified;
	String[] number_of_persons_in_household;
	String[] number_of_cars;
	String[] college_education;
	String[] dwelling_type;
	List<Preference> preferences;
	List<Characteristic>characteristics;
	List<PsychologicalTrend> psychological_trends;
	List<Predesipositions> predesipositions;
	List<Behavior> behavior;
	List<Attitude> attitudes;
	List<Intelligence> intelligence;
	List<Ability> abilities;
	List<Aptitude> aptitudes;
	List<PersonalInterest> personal_interests;
	
}
