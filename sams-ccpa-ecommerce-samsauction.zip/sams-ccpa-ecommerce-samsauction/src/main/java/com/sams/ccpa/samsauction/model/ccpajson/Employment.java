package com.sams.ccpa.samsauction.model.ccpajson;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Employment {
	String employer;
	String employment_type;
	String annual_household_income;
	String employment_status;
	String job_title;
	String employee_number;
	String employee_security_ID;
	String date_hired;
	String date_started_in_current_position;
	String wage_type;
	String wage_effective_date;
	String average_weekly_wage_method;
	String average_weekly_wage;
	String average_other_wage;
	String bonus_amount;
	String overtime_wage_amount;
	String amount_of_commission_earned;
	String amount_of_fringe_benefits;

}
