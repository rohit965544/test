package com.sams.ccpa.samsauction.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class DeviceInfo {
	String brand;
	String product;
	String device;
	String android_uuid;
	String device_manufacturer;
	String platform;
	String os_version;
	String  device_model;
	String screen_height;
	String  screen_width;
	String screen_dpi;
	String device_country;
	String locale_language;
	String locale_country;
	String network_country;
	String network_carrier;
	String network_code;
	String network_mobile_country_code;
	String timezone_offset;
	String build_identifier;
	String  http_header_user_agent;
	String ios_advertising_id;
	String push_token;
	String cpu_architecture;
	String  is_tablet;
	String push_notification_sound_enabled;
	String push_notification_vibrate_enabled;
	String radio_access_technology;
	String supports_telephony;
	String has_nfc;
	String bluetooth_enabled;
	String bluetooth_version;
	String ios_idfv;
	String android_advertising_id;
	String limit_ad_tracking;
	String is_dst;
	String roku_advertising_id;
	String roku_publisher_id;
	String microsoft_advertising_id;
	String microsoft_publisher_id;
	String fire_advertising_id;
}
