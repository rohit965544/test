package com.sams.ccpa.samsauction.model.ccpajson;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class HealthInsuranceInformation {
	String[] alleged_cause_of_injury;
	String[] initial_treatment_code_description;
	String[] treatment;
	String[] sleep_data;
	String[] exercise_data;
	String[] drug_test_results;
	String[] family_health_or_morbidity_history;
	String[] diagnosis;
	String[] payments;
	String[] claims_data;
	String[] medical_images_xref;
	String[] prescription_number;
	String[] insurance_number;
	String[] is_medicare_eligible;
	String[] percent_disability;
	String[] injured_location;
	String[] injured_fingers_and_or_toes_location;
	String[] illness_type_description;
	String[] injury_type_description;
	String[] injury_severity;
	String[] prior_medical_condition;
	String[] nature_of_injury;
	String[] part_of_body_code_description;
	String[] therapies;
	String[] drugs;
	String[] medical_products_used;
	String[] does_claimant_want_their_name_excluded_from_the_OSHA_log;
}
