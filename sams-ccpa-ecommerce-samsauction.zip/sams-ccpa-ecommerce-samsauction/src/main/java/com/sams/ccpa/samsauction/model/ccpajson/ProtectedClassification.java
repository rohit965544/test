package com.sams.ccpa.samsauction.model.ccpajson;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ProtectedClassification {
	String[] sex;
	 String[] gender;
	 String[] race;
	 String[] religion;
	 String[] color;
	 String[] national_origin;
	 String[] disability;
	 String[] sexual_orientation;
	 String[] marital_status;
	 String[] familial_status;
	 String[] medical_condition;
	 String[] military_or_veteran_status;
	 String[] ancestry;
	 String[] nationality;
	 String[] country_of_birth;
	 String[] citizenship;
	 String[] genetic_test_result;
	 String[] age;
}
