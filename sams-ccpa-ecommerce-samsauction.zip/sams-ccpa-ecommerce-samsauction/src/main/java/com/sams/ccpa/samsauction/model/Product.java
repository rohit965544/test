package com.sams.ccpa.samsauction.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Product {

	
	String name;
	String total_product_amount;
	String added_to_cart_time_ms;
	
}
