package com.sams.ccpa.samsauction.model.clearhousejson;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PIBlob {
	private String intakeID;
	private String brands;
	private String customerID;
	private String standardizedSubjectAddress1;
	private String standardizedSubjectCity;
	private String standardizedSubjectState;
	private String standardizedSubjectZip;
	private String requestTimestamp;
}
