package com.sams.ccpa.samsauction.model.ccpajson;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@JsonInclude(Include.NON_NULL)
public class DeviceAndOnlineIdentifiers {
	String online_identifier;
	String internet_protocol_address;
	String device_id;
	String serial_number;
	String device_calendar_information;
	String device_contact_information;
	String device_version_control;
	String device_os;
	String mobile_platform;
	String mobile_app_version;
}
