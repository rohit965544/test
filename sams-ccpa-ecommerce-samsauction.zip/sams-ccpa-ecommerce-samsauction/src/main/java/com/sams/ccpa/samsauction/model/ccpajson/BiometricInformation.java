package com.sams.ccpa.samsauction.model.ccpajson;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BiometricInformation {
	String[] voice_recording_xref;
	String[] fingerprint_xref;
	String[] face_xref;
}
