package com.sams.ccpa.samsauction.model.ccpajson;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class DriversLicense {
	String drivers_license_state;
	String drivers_license_country;
	String drivers_license_number;
}
