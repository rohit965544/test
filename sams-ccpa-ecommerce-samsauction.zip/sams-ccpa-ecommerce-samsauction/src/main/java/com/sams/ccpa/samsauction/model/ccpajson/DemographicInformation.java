package com.sams.ccpa.samsauction.model.ccpajson;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class DemographicInformation {
	 String[] age;
	 String[] date_of_birth;
	 String[] date_of_death;
	 String[] claimant_death_caused_by_injury;
	 String[] height;
	 String[] weight;
	 String[] tax_filing_status;
	 List<LanguageSkill> language_skills;
	 String[] number_of_children;
	 String[] number_of_dependents;
	 String[] household_income;
}
